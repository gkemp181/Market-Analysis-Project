import os
import numpy as np
import pandas as pd
from scipy.stats import pearsonr
from itertools import combinations, product

def get_ticker_comb(n_periods=10):
    # get all tickers (basically atp all files)
    files = os.listdir("./data/15m") or os.listdir("./data/1d")
    tickers = [file.split("_")[0] for file in files]
    periods = list(range(1, n_periods))
    yield from product(combinations(tickers, 2), periods)


def get_ticker(ticker, interval):
    """ get the ticker data """
    with open(f"./data/{interval}/{ticker.upper()}_{interval}.csv") as csv:
        return pd.read_csv(csv)


def shift_ticker_data(ticker1, ticker2, shift):
    ticker1 = ticker1.shift(shift)
    ticker1 = ticker1.dropna()
    return ticker1, ticker2.iloc[:-shift]


def get_correlation_m1(ticker1, ticker2, interval, periods=1):
    """ get the correlation between two tickers (method 1) """
    # get the tickers
    ticker1 = get_ticker(ticker1, interval)
    ticker2 = get_ticker(ticker2, interval)

    # lag one ticker by given interval
    ticker1, ticker2 = shift_ticker_data(ticker1, ticker2, periods)

    # normalize the data (pct change)
    ticker1["Pct_Change"] = ticker1["Close"].pct_change(periods=periods)
    ticker2["Pct_Change"] = ticker2["Close"].pct_change(periods=periods)
    ticker1, ticker2 = ticker1.dropna(), ticker2.dropna()

    # return the correlation
    return pearsonr(ticker1["Pct_Change"], ticker2["Pct_Change"])


if __name__ == "__main__":
    # get the correlation between two tickers
    results = { "data": [] }

    interval = "15m"
    for [ticker1, ticker2], period in get_ticker_comb():
        result = get_correlation_m1(ticker1, ticker2, interval, period)
        results["data"].append({
            "Ticker1": ticker1,
            "Ticker2": ticker2,
            "Shift_Periods": period,
            "Correlation": result[0],
            "P-Value": result[1]
        })

    results_df = pd.DataFrame(results["data"])
    print(results_df.head())
    results_df.to_csv(f"./data/correlation_results_{interval}.csv")
