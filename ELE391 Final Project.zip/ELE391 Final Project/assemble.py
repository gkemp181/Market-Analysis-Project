import os
import json
import time
import datetime
import requests
import pandas as pd
import yfinance as yf
from pathlib import Path
import pandas_market_calendars as mcal


NASDAQ_STOCKS = "https://api.nasdaq.com/api/screener/stocks?tableonly=true&download=true"
NASDAQ_HEADERS = {
    "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
    "Referer": "https://github.com/ranaroussi/yfinance/discussions/1699",
}


def get_tickers():
    """ get the list of tickers from the nasdaq api """

    # the data is already downloaded ; return it
    if Path("./data/stocks.json").exists():
        with open("./data/stocks.json", "r") as file:
            data = json.load(file)
            return pd.DataFrame(data["data"]["rows"])

    # we must download the data ; save it and then recurse
    os.makedirs("./data", exist_ok=True)
    with open("./data/stocks.json", "w") as file:
        file.write(requests.get(NASDAQ_STOCKS, headers=NASDAQ_HEADERS).text)
        return get_tickers()


def get_valid_tickers():
    """ get filtered tickers as list """
    tickers = get_tickers()
    tickers =  tickers[tickers["lastsale"] != "N/A"]["symbol"].tolist()
    tickers = [ticker for ticker in tickers if not "." in ticker]
    tickers = [ticker for ticker in tickers if not "/" in ticker]
    return tickers


def get_start_end_dates(period_in_days):
    """ get start and end dates for period in days """

    # if the period is 60 days, we are trying to get last 60days from api storage
    if period_in_days == 60:
        start = datetime.datetime.now() - datetime.timedelta(days=55)
        end = datetime.datetime.now()
        return str(start).split()[0], str(end).split()[0]

    # because the market is closed on weekends, and holidays
    # the first start and end dates should be much larger than
    # the desired period, we filter down later
    start = datetime.datetime.now() - datetime.timedelta(days=2*period_in_days)
    end = datetime.datetime.now()

    # get the schedule for the NYSE
    nyse = mcal.get_calendar("NYSE")
    sched = nyse.schedule(start_date=start, end_date=end)

    # get the last period_in_days
    start, end = str(sched.index[-period_in_days]), str(sched.index[-1])
    start, end = start.split()[0], end.split()[0]
    return start, end


def get_stock_data(tickers, interval="15m", start=None, end=None, period_d=60):
    """ get the stock data for the given tickers """
    start, end = get_start_end_dates(period_d) if start is None else (start, end)
    return yf.download(tickers, start=start, end=end, interval=interval)


def save_file_and_tickers(stock_data, interval):
    """ save the stock data and tickers """
    path_to_dir = f"./data/{interval}_{time.time():.0f}"
    os.makedirs(path_to_dir, exist_ok=True)

    stock_data.to_csv(f"{path_to_dir}/stock_data_{interval}.csv")
    for ticker in stock_data.columns.levels[1]:
        data = { key: stock_data[key][ticker] for key in stock_data.columns.levels[0] }
        pd.DataFrame(data).dropna().to_csv(f"{path_to_dir}/{ticker}_{interval}.csv")


if __name__ == "__main__":
    # 1 , get the tickers
    start = time.time()
    print("[*] Getting tickers from NASDAQ")
    tickers = get_valid_tickers()
    print(f"[*] Retrieved tickers from NASDAQ in {time.time() - start:.2f}s")

    # 2 , download the stock data (15m)
    start = time.time()
    print("[*] Downloading stock data for 15m intervals")
    stock_data_15 = get_stock_data(tickers, interval="15m", period_d=60)
    save_file_and_tickers(stock_data_15, "15m")
    print(f"[*] Downloaded stock data for 15m intervals in {time.time() - start:.2f}s")

    # 3 , download the stock data (1d)
    start = time.time()
    print("[*] Downloading stock data for 1d intervals")
    stock_data_1 = get_stock_data(tickers, interval="1d", period_d=2*365)
    save_file_and_tickers(stock_data_1, "1d")
    print(f"[*] Downloaded stock data for 1d intervals in {time.time() - start:.2f}s")
