---
title: Hmm Market Analysis
emoji: 💻
colorFrom: blue
colorTo: gray
sdk: gradio
sdk_version: 5.8.0
app_file: app.py
pinned: false
license: mit
short_description: Using an HMM to analyze different regime (market conditions)
---

Check out the configuration reference at https://huggingface.co/docs/hub/spaces-config-reference
