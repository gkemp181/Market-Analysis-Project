import ta
import pandas as pd
import gradio as gr
import yfinance as yf
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import matplotlib.patches as mpatches
from hmmlearn.hmm import GaussianHMM
from sklearn.preprocessing import StandardScaler

css = """
ol, ul {
    padding-left: 20px;
}
"""

REGIME_COLORS = ["orange", "red", "green", "gray", "blue", "purple",
                 "pink", "brown", "black", "yellow", "cyan", "magenta"]


def generate_regime_map(n):
    return {f"Regime {i}": REGIME_COLORS[i] for i in range(n)}


def train_hmm(df, columns, n_states, TRAIN_SIZE=0.8):
    """
    Train an HMM Model on the given data, using the specified columns and
    number of hidden states. Returns the dataframe with an additional column
    'Hidden_State' indicating the regime assigned by the model.
    """
    VAL_SIZE = 1 - TRAIN_SIZE

    # Scale the data
    data = StandardScaler().fit_transform(df[columns])

    # Create the model
    model = GaussianHMM(n_components=n_states, covariance_type="full", random_state=42)

    # Fit the model
    model.fit(data[:int(len(data)*(TRAIN_SIZE+VAL_SIZE))])

    # Predict the hidden states
    df['Hidden_State'] = model.predict(data)

    # Ensure 'Hidden_State' is a categorical variable for better color handling
    df['Hidden_State'] = df['Hidden_State'].astype('category')

    # Return dataframe
    return df


def plot_hmm(df, columns, n_states, TRAIN_SIZE=0.8):
    # Create the plot
    _, ax = plt.subplots(figsize=(10, 6))

    # Format the x-axis
    ax.xaxis.set_major_locator(mdates.MonthLocator(interval=4))
    ax.xaxis.set_major_formatter(mdates.DateFormatter('%Y-%m-%d'))
    plt.gcf().autofmt_xdate()  # Rotate date labels

    # Plot the line with hue for hidden states
    index = pd.to_datetime(df['Date'])
    last = index.iloc[0], df['Close'].iloc[0], df['Hidden_State'].iloc[0]

    # Create a map of hidden states to colors
    regime_map = generate_regime_map(n_states)
    color_list = [list(regime_map.values())[state] for state in df['Hidden_State']]

    for x, y, state, color in zip(index, df['Close'], df['Hidden_State'], color_list):
        lx, ly, ls = last
        plt.plot([lx, x], [ly, y], color=color, linewidth=2)
        last = x, y, state

    # Set x-axis limits explicitly
    ax.set_xlim(index.min(), index.max())

    # Add title and labels
    plt.title("Hidden Markov Model", fontsize=14)
    plt.xlabel("Date", fontsize=12)
    plt.ylabel("Close Price ($)", fontsize=12)

    # Add a label for each regime
    for i, [_, color] in enumerate(regime_map.items()):
        square = mpatches.Rectangle((0.02, 0.92 - 0.05 * i), 0.03, 0.03, color=color, transform=ax.transAxes)
        ax.add_patch(square)
        ax.text(0.06, 0.93 - 0.05 * i, f"Regime #{i+1}",
                transform=ax.transAxes, fontsize=10, verticalalignment="center")

    # Line showing where training ended
    train_start_idx = int(len(df) * TRAIN_SIZE)

    ax.axvspan(index.iloc[train_start_idx], index.iloc[-1], alpha=0.2)
    ax.text(0.72, 0.93, "Validation Region", transform=ax.transAxes)

    # Final adjustments
    plt.tight_layout()
    return plt


def validate_ticker(asset: str):
    """
    Checks if an asset is available via the Yahoo Finance API.
    Returns a validity status message.
    """
    try:
        info = yf.Ticker(asset).history(period="1d", interval="1d")
        msg = "Ticker Symbol is Valid" if len(info) > 0 else "Ticker Symbol is Invalid"
        return msg, gr.update(visible=len(info) > 0)
    except Exception as e:
        return f"Error: {str(e)}", gr.update(visible=False)


def get_ticker_data(asset: str):
    df = yf.Ticker(asset).history(period="2y", interval="1d")
    df = ta.add_all_ta_features(df, open="Open", high="High", low="Low", close="Close", volume="Volume", fillna=True)
    df = df.dropna(axis=1)
    df['Date'] = df.index
    return df


COLUMNS_TA = {
    "accumulation_distribution_index": "volume_adi",
    "on_balance_volume": "volume_obv",
    "chaikin_money_flow": "volume_cmf",
    "force_index": "volume_fi",
    "ease_of_movement": "volume_em",
    "sma_ease_of_movement": "volume_sma_em",
    "volume_price_trend": "volume_vpt",
    "volume_weighted_average_price": "volume_vwap",
    "money_flow_index": "volume_mfi",
    "negative_volume_index": "volume_nvi",
    "bollinger_bands_mean": "volatility_bbm",
    "bollinger_bands_high": "volatility_bbh",
    "bollinger_bands_low": "volatility_bbl",
    "bollinger_bands_width": "volatility_bbw",
    "bollinger_bands_percentage": "volatility_bbp",
    "bollinger_band_high_indicator": "volatility_bbhi",
    "bollinger_band_low_indicator": "volatility_bbli",
    "keltner_channel_center": "volatility_kcc",
    "keltner_channel_high": "volatility_kch",
    "keltner_channel_low": "volatility_kcl",
    "keltner_channel_width": "volatility_kcw",
    "keltner_channel_percentage": "volatility_kcp",
    "keltner_channel_high_indicator": "volatility_kchi",
    "keltner_channel_low_indicator": "volatility_kcli",
    "donchian_channel_low": "volatility_dcl",
    "donchian_channel_high": "volatility_dch",
    "donchian_channel_mean": "volatility_dcm",
    "donchian_channel_width": "volatility_dcw",
    "donchian_channel_percentage": "volatility_dcp",
    "average_true_range": "volatility_atr",
    "ulcer_index": "volatility_ui",
    "macd": "trend_macd",
    "macd_signal": "trend_macd_signal",
    "macd_difference": "trend_macd_diff",
    "simple_moving_average_fast": "trend_sma_fast",
    "simple_moving_average_slow": "trend_sma_slow",
    "exponential_moving_average_fast": "trend_ema_fast",
    "exponential_moving_average_slow": "trend_ema_slow",
    "vortex_indicator_positive": "trend_vortex_ind_pos",
    "vortex_indicator_negative": "trend_vortex_ind_neg",
    "vortex_indicator_difference": "trend_vortex_ind_diff",
    "triple_exponential_average": "trend_trix",
    "mass_index": "trend_mass_index",
    "detrended_price_oscillator": "trend_dpo",
    "know_sure_thing": "trend_kst",
    "know_sure_thing_signal": "trend_kst_sig",
    "know_sure_thing_difference": "trend_kst_diff",
    "ichimoku_conversion_line": "trend_ichimoku_conv",
    "ichimoku_base_line": "trend_ichimoku_base",
    "ichimoku_ahead_a": "trend_ichimoku_a",
    "ichimoku_ahead_b": "trend_ichimoku_b",
    "stochastic_turbo_crossover": "trend_stc",
    "average_directional_index": "trend_adx",
    "average_directional_index_positive": "trend_adx_pos",
    "average_directional_index_negative": "trend_adx_neg",
    "commodity_channel_index": "trend_cci",
    "visual_ichimoku_a": "trend_visual_ichimoku_a",
    "visual_ichimoku_b": "trend_visual_ichimoku_b",
    "aroon_up": "trend_aroon_up",
    "aroon_down": "trend_aroon_down",
    "aroon_indicator": "trend_aroon_ind",
    "parabolic_sar_up": "trend_psar_up",
    "parabolic_sar_down": "trend_psar_down",
    "parabolic_sar_up_indicator": "trend_psar_up_indicator",
    "parabolic_sar_down_indicator": "trend_psar_down_indicator",
    "relative_strength_index": "momentum_rsi",
    "stochastic_rsi": "momentum_stoch_rsi",
    "stochastic_rsi_k": "momentum_stoch_rsi_k",
    "stochastic_rsi_d": "momentum_stoch_rsi_d",
    "true_strength_index": "momentum_tsi",
    "ultimate_oscillator": "momentum_uo",
    "stochastic_oscillator": "momentum_stoch",
    "stochastic_signal": "momentum_stoch_signal",
    "williams_percent_range": "momentum_wr",
    "awesome_oscillator": "momentum_ao",
    "rate_of_change": "momentum_roc",
    "percentage_price_oscillator": "momentum_ppo",
    "ppo_signal": "momentum_ppo_signal",
    "ppo_histogram": "momentum_ppo_hist",
    "percentage_volume_oscillator": "momentum_pvo",
    "pvo_signal": "momentum_pvo_signal",
    "pvo_histogram": "momentum_pvo_hist",
    "kaufman_adaptive_moving_average": "momentum_kama",
    "daily_return": "others_dr",
    "daily_log_return": "others_dlr",
    "cumulative_return": "others_cr",
}

COLUMNS = {
    "open": "Open",
    "high": "High",
    "low": "Low",
    "close": "Close",
    "volume": "Volume",
}


with gr.Blocks(css=css) as demo:
    gr.Markdown(
        """
    # HMM Market Analysis
    
    Hidden Markov Models (HMMs) are a statistical modeling technique commonly used to analyze sequential or 
    time-series data, such as stock market prices. They are useful for identifying patterns 
    (hidden states) in time-series data.

    ## What are Hidden Markov Models (HMMs)?

    An HMM is composed of two main components:
    1.	**Hidden States**: These represent the unobservable or latent factors driving the system. For the stock market, these could be regimes such as “bullish,” “bearish,” or “sideways.”
    2.	**Observations**: These are the measurable outputs, like daily stock prices or trading volumes, which are influenced by the hidden states.

    The model assumes:
    1. The system transitions between hidden states according to a Markov process, where the probability of transitioning to the next state depends only on the current state (not the sequence of previous states).
    2. Observations are generated probabilistically from the hidden states.

    In financial analysis, regimes represent different market conditions or behaviors that can impact asset prices. We can use HMMs to attempt to uncover these hidden regimes from observed market data.
    By identifying regimes, analysts can better understand market dynamics and potentially make more informed investment decisions.

    ## Why is HMM Unsupervised?

    HMMs are considered an unsupervised learning model because they do not require labeled data to train. Instead, the model infers hidden states and their characteristics based purely on the patterns in the observed data. However, this comes with a key challenge:
    - **Manual Analysis**: After training the model, analysts must interpret the hidden states and match them to meaningful regimes or behaviors. For example, a state with high volatility and declining returns might correspond to a bearish regime.

    # This Tool
    
    This tool helps you analyze stock market data using Hidden Markov Models. 
    You must first:
    - select a ticker symbol and time interval to fetch data from an API.
    - choose columns to feed into the model.
    - specify the number of hidden states to identify.
    
    ~ This tool was made for ELE 391 @ the University of Rhode Island, taught by Dr. Chiovaro.
    """)

    interval = "1d"

    with gr.Row():
        with gr.Column(scale=1):
            ticker_input = gr.Textbox(label="Ticker Symbol", value="AAPL", lines=1, max_length=8)
        with gr.Column(scale=1):
            interval = gr.Radio(label="Interval", choices=["1d"])

        validity_label = gr.Text(label="Validation Result", value="Ticker Symbol is Valid")

    # hide next steps if ticker is invalid
    with gr.Row() as next_steps:
        with gr.Column():
            gr.Markdown(
                """
                **Next Steps:**
                1. Select the columns to include in the model.
                2. Specify the number of hidden states.
                3. Click "Fetch Data" to proceed.
                """
            )

            selected_cols_1 = list(COLUMNS.keys())
            c1 = gr.CheckboxGroup(list(COLUMNS.keys()), label="Columns", value=selected_cols_1)

            def update_selected_cols_1(value):
                selected_cols_1 = value
                return selected_cols_1

            c1.change(
                fn=update_selected_cols_1,
                inputs=[c1],
                outputs=[]
            )

            selected_cols_2 = list(COLUMNS_TA.keys())[:3]
            c2 = gr.CheckboxGroup(
                list(COLUMNS_TA.keys()),
                label="Columns (Technical Indicators)", value=selected_cols_2)

            def update_selected_cols_2(value):
                selected_cols_2 = value
                return selected_cols_2

            c2.change(
                fn=update_selected_cols_2,
                inputs=[c2],
                outputs=[]
            )
            n_states = gr.Slider(
                minimum=0,
                maximum=9,
                step=1,
                value=8,  # Initial value
                label="Number of Hidden States",
            )

            n_states.change(lambda n: gr.update(visible=True), inputs=[n_states], outputs=[n_states])

    data = None

    def get_cols(col1, col2):
        cols = []
        for col in col1:
            cols.append(COLUMNS[col])
        for col in col2:
            cols.append(COLUMNS_TA[col])
        return cols

    def if_can_plot_do_plot(data, cols, n_states):
        if data is not None:
            return plot_hmm(data, cols, n_states)
        return None

    with gr.Row():
        plot = gr.Plot(label="HMM Plot")

    def fetch_data():
        global data
        data = get_ticker_data(ticker_input.value)
        data = train_hmm(data, get_cols(selected_cols_1, selected_cols_2), n_states.value)
        return plot_hmm(data, get_cols(selected_cols_1, selected_cols_2), n_states.value)

    fetch_btn = gr.Button("Generate 🚀")
    fetch_btn.click(fetch_data, outputs=[plot])

    # Validate ticker onchange
    ticker_input.change(
        fn=validate_ticker,
        inputs=[ticker_input],
        outputs=[validity_label, next_steps]
    )

demo.launch()
