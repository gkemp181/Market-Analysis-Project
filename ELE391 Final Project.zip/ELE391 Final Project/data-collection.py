import requests
import pandas as pd
import yfinance as yf
from datetime import datetime
from typing import Literal, Optional
# from correlation import get_correlation_m1


def _extract_period(period: str) -> pd.DateOffset | None:
    if "day" in period or period[-1] == "d":
        return pd.DateOffset(days=int(period[:-1]))
    if "year" in period or period[-1] == "y":
        return pd.DateOffset(years=int(period[:-1]))
    if "month" in period or period[-2:] == "mo":
        return pd.DateOffset(months=int(period[:-2]))
    if "week" in period or period[-1] == "w":
        return pd.DateOffset(weeks=int(period[:-1]))
    if "hour" in period or period[-1] == "h":
        return pd.DateOffset(hours=int(period[:-1]))
    if "minute" in period or period[-1] == "m":
        return pd.DateOffset(minutes=int(period[:-1]))
    if "second" in period or period[-1] == "s":
        return pd.DateOffset(seconds=int(period[:-1]))
    return None

# def _get_correlation(ticker: str) -> pd.DataFrame:
#     """
#     We actually do not care what the interval is here,
#     as we can claim that the correlation remains constant
#     given any interval. Though this may not be 100% true,
#     it is a "good enough" assumption for the machine learning
#     model.
#     """
#     return get_correlation_m1(ticker)


def _get_dcf_data(ticker: str, period: str) -> dict:
    apikey = "koxw7RFn4MuRbqTBYxjb80EEGrPdRcRl"

    data = requests.get(
        f"https://financialmodelingprep.com/api/v3/discounted-cash-flow/{ticker}?apikey={apikey}")
    data2 = requests.get(
        f"https://financialmodelingprep.com/api/v3/income-statement/{ticker}?apikey={apikey}")

    return {
        **data.json()[0],
        **data2.json()[0]
    }


def _get_sentiment_data(ticker: str, limit: int = 50) -> dict:
    apikey = "AAC71G0EPCF7I07V"

    data = requests.get(
        "https://www.alphavantage.co/" +
        "query?function=NEWS_SENTIMENT&" +
        f"tickers={ticker}&apikey={apikey}"
    )

    return data.json()


def create_dataset(
    ticker: str,
    interval: Literal["15m", "1d"],
    start: Optional[str] = None,
    end: str = datetime.today().strftime('%Y-%m-%d'),
    period: str = "1y",
):
    # Validate the interval
    assert interval in ["15m", "1d"], "Interval must be either 15m or 1d"

    # If there is no start, calculate using today's date as the end
    if start is None:
        period_offset = _extract_period(period)
        assert period_offset is not None, "Period must be valid (e.g. 1y, 1mo, 1d, etc.)"
        start = (datetime.fromisoformat(end) - period_offset).strftime('%Y-%m-%d')

    # Now, we have enough information to download the data from yfinance
    stock_data = yf.download(ticker, start=start, end=end,
                             interval=interval, progress=False)
    return stock_data
    # Now, we
